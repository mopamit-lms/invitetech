# Roadmap
- [x] RTL Hebrew base, Prismind branding
- [x] Booking calendar (Nov 4 – Dec 31 2026, Sun–Wed, 09:00–13:00)
- [x] Single service: teacher technology accompaniment; teacher count + full school details required
- [x] Lovable Cloud: bookings saved; one booking per school and one per date enforced in database
- [ ] SMS one-time-code login (blocked: needs SMS provider account, e.g. Twilio)
- [x] Admin screens (approval queue, assign Tal/Shani, calendar, blocked days)
- [x] Grant Tal & Shani admin (emails added; each must sign up once at /auth)
- [x] Bell hours (שעות הצלצולים) is a required field in the booking form
- [x] Remove the "כל בית ספר יכול להזמין פעם אחת בלבד" note from the form
