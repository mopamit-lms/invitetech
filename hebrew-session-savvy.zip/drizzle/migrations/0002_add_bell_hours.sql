ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS bell_hours text;
COMMENT ON COLUMN public.bookings.bell_hours IS 'שעות הצלצולים של בית הספר, כפי שנמסרו בטופס ההזמנה';