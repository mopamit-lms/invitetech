CREATE OR REPLACE FUNCTION public.only_admin_emails_signup()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.admin_emails WHERE lower(email) = lower(NEW.email)) THEN
    RAISE EXCEPTION 'signup_not_allowed';
  END IF;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS on_auth_user_before_insert_restrict ON auth.users;
CREATE TRIGGER on_auth_user_before_insert_restrict BEFORE INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.only_admin_emails_signup();