CREATE TABLE public.bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_date date NOT NULL,
  school_name text NOT NULL,
  school_symbol text NOT NULL,
  city text NOT NULL,
  contact_name text NOT NULL,
  contact_role text,
  contact_phone text NOT NULL,
  contact_email text NOT NULL,
  teachers_count integer NOT NULL,
  notes text,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.bookings TO service_role;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
CREATE UNIQUE INDEX bookings_one_per_date ON public.bookings (session_date) WHERE status <> 'cancelled';
CREATE UNIQUE INDEX bookings_one_per_school ON public.bookings (school_symbol) WHERE status <> 'cancelled';