import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Eye, EyeOff } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Prismind – כניסת צוות" },
      { name: "description", content: "כניסה לממשק הניהול של צוות Prismind." },
      { property: "og:title", content: "Prismind – כניסת צוות" },
      { property: "og:description", content: "כניסה לממשק הניהול של צוות Prismind." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const nav = useNavigate();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [show, setShow] = useState(false);

  async function go(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setMsg(null);
    if (mode === "in") {
      const { error } = await supabase.auth.signInWithPassword({ email, password: pw });
      if (error) setMsg("אימייל או סיסמה שגויים.");
      else nav({ to: "/admin" });
    } else {
      const { error } = await supabase.auth.signUp({ email, password: pw, options: { emailRedirectTo: `${window.location.origin}/admin` } });
      if (!error) setMsg("נשלח אליך מייל לאימות. לאחר האימות אפשר להיכנס.");
      else if (/weak|pwned|leaked/i.test(error.message)) setMsg("הסיסמה חלשה או מוכרת מדי. בחרו סיסמה אחרת (לפחות 6 תווים).");
      else if (/database|not_allowed|saving/i.test(error.message)) setMsg("ההרשמה פתוחה רק למיילים של צוות Prismind.");
      else if (/registered|exists/i.test(error.message)) setMsg("המייל כבר רשום – לחצו על כניסה.");
      else setMsg("ההרשמה נכשלה: " + error.message);
    }
    setBusy(false);
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <form onSubmit={go} className="w-full max-w-sm space-y-3 rounded-2xl border border-border bg-card p-6">
        <Link to="/" className="block text-sm text-primary underline">← חזרה ליומן</Link>
        <h1 className="text-xl font-bold">{mode === "in" ? "כניסת צוות" : "הרשמת צוות"}</h1>
        <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="אימייל" className="w-full rounded-lg border border-input bg-background p-2" />
        <div className="relative">
          <input type={show ? "text" : "password"} required minLength={6} value={pw} onChange={(e) => setPw(e.target.value)} placeholder="סיסמה" className="w-full rounded-lg border border-input bg-background p-2 pl-10" />
          <button type="button" onClick={() => setShow(!show)} aria-label={show ? "הסתרת סיסמה" : "הצגת סיסמה"} className="absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
            {show ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
          </button>
        </div>
        {msg && <p role="alert" className="text-sm text-muted-foreground">{msg}</p>}
        <button disabled={busy} className="w-full rounded-lg bg-primary py-2.5 font-medium text-primary-foreground disabled:opacity-50">{mode === "in" ? "כניסה" : "הרשמה"}</button>
        <button type="button" onClick={() => setMode(mode === "in" ? "up" : "in")} className="w-full text-sm text-primary underline">
          {mode === "in" ? "פעם ראשונה? הרשמה" : "יש לי חשבון – כניסה"}
        </button>
      </form>
    </div>
  );
}
