import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { amIAdmin, listAdminData, setBlockedDay, updateBooking } from "@/lib/admin.functions";
import { BLOCKED, WINDOW_END, WINDOW_START, iso } from "@/lib/booking";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Prismind – ממשק ניהול" },
      { name: "description", content: "ניהול בקשות, שיבוץ מדריכים וזמינות ימים." },
      { property: "og:title", content: "Prismind – ממשק ניהול" },
      { property: "og:description", content: "ניהול בקשות, שיבוץ מדריכים וזמינות ימים." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AdminPage,
});

const STATUS: Record<string, string> = {
  pending: "ממתין לאישור", approved: "מאושר", rejected: "נדחה", proposed: "הוצע מועד חלופי", cancelled: "בוטל",
};
const fmt = (d: string) => new Date(d + "T12:00:00").toLocaleDateString("he-IL", { weekday: "short", day: "numeric", month: "long" });
const TABS = [["queue", "תור בקשות"], ["calendar", "יומן כללי"], ["days", "חסימת ימים"]] as const;

function activeDays() {
  const out: string[] = [];
  for (let d = new Date(WINDOW_START + "T12:00:00"); iso(d) <= WINDOW_END; d.setDate(d.getDate() + 1))
    if (d.getDay() <= 3) out.push(iso(d));
  return out;
}

function AdminPage() {
  const nav = useNavigate();
  const qc = useQueryClient();
  const checkAdmin = useServerFn(amIAdmin);
  const load = useServerFn(listAdminData);
  const upd = useServerFn(updateBooking);
  const block = useServerFn(setBlockedDay);
  const [tab, setTab] = useState<(typeof TABS)[number][0]>("queue");
  const [err, setErr] = useState<string | null>(null);

  const admin = useQuery({ queryKey: ["isAdmin"], queryFn: () => checkAdmin() });
  const data = useQuery({ queryKey: ["admin"], queryFn: () => load(), enabled: admin.data === true });

  async function signOut() {
    await qc.cancelQueries(); qc.clear();
    await supabase.auth.signOut();
    nav({ to: "/auth", replace: true });
  }

  async function run(p: Promise<{ ok: boolean; error?: string }>) {
    setErr(null);
    try { const r = await p; if (!r.ok) setErr(r.error ?? "שגיאה"); }
    catch { setErr("הפעולה נכשלה."); }
    qc.invalidateQueries({ queryKey: ["admin"] });
  }
  const act = (id: string, action: "approve" | "reject" | "propose" | "assign" | "cancel", extra: object = {}) =>
    run(upd({ data: { id, action, ...extra } }));

  if (admin.isLoading) return <p className="p-6">טוען…</p>;
  if (!admin.data)
    return (
      <div className="p-6 space-y-3">
        <p>לחשבון הזה אין הרשאת ניהול. פנו לטל או לשני.</p>
        <Link to="/" className="text-primary underline me-4">חזרה ליומן</Link>
        <button onClick={signOut} className="text-primary underline">יציאה</button>
      </div>
    );

  const bookings = data.data?.bookings ?? [];
  const blocked = Object.fromEntries((data.data?.blocked ?? []).map((b) => [b.day, b.reason]));
  const active = bookings.filter((b) => b.status !== "rejected" && b.status !== "cancelled");
  const byDate = Object.fromEntries(active.map((b) => [b.session_date, b]));
  const queue = bookings.filter((b) => b.status === "pending" || b.status === "proposed");
  const days = activeDays();
  const freeDays = days.filter((d) => !byDate[d] && !blocked[d] && !BLOCKED[d]);

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="mx-auto flex max-w-4xl items-center justify-between px-4 py-3">
          <h1 className="text-lg font-bold">ממשק ניהול</h1>
          <div className="flex items-center gap-4 text-sm">
            <Link to="/" className="text-primary underline">חזרה ליומן</Link>
            <button onClick={signOut} className="text-primary underline">יציאה</button>
          </div>
        </div>
        <nav className="mx-auto flex max-w-4xl gap-1 px-4">
          {TABS.map(([k, l]) => (
            <button key={k} onClick={() => setTab(k)} className={`rounded-t-lg px-3 py-2 text-sm ${tab === k ? "bg-background font-semibold" : "text-muted-foreground"}`}>
              {l}{k === "queue" && queue.length > 0 && ` (${queue.length})`}
            </button>
          ))}
        </nav>
      </header>

      <main className="mx-auto max-w-4xl space-y-4 px-4 py-6">
        {err && <p role="alert" className="rounded-lg bg-destructive/10 p-2 text-sm text-destructive">{err}</p>}
        {data.isLoading && <p>טוען…</p>}

        {tab === "queue" && (queue.length === 0 ? <p className="text-muted-foreground">אין בקשות ממתינות.</p> :
          queue.map((b) => (
            <article key={b.id} className="space-y-2 rounded-2xl border border-border bg-card p-4">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <h2 className="font-semibold">{b.school_name} · {b.city}</h2>
                <span className="text-sm text-muted-foreground">{STATUS[b.status]}</span>
              </div>
              <p className="text-sm">
                {fmt(b.session_date)}{b.original_date && ` (במקום ${fmt(b.original_date)})`} · {b.teachers_count} מורים · סמל {b.school_symbol}
              </p>
              <p className="text-sm text-muted-foreground">{b.contact_name}{b.contact_role && ` (${b.contact_role})`} · {b.contact_phone} · {b.contact_email}</p>
              {b.bell_hours && <p className="text-sm">שעות צלצולים: {b.bell_hours}</p>}
              {b.notes && <p className="text-sm">הערות: {b.notes}</p>}
              <div className="flex flex-wrap items-center gap-2 pt-1">
                <button onClick={() => act(b.id, "approve")} className="rounded-lg bg-primary px-3 py-1.5 text-sm text-primary-foreground">אישור</button>
                <button onClick={() => act(b.id, "reject")} className="rounded-lg border border-border px-3 py-1.5 text-sm">דחייה</button>
                <select defaultValue="" onChange={(e) => e.target.value && act(b.id, "propose", { date: e.target.value })} className="rounded-lg border border-input bg-background px-2 py-1.5 text-sm">
                  <option value="">הצעת מועד חלופי…</option>
                  {freeDays.map((d) => <option key={d} value={d}>{fmt(d)}</option>)}
                </select>
                <Assign value={b.instructor} onChange={(v) => act(b.id, "assign", { instructor: v })} />
              </div>
            </article>
          )))}

        {tab === "calendar" && (
          <div className="overflow-hidden rounded-2xl border border-border bg-card">
            {days.map((d) => {
              const b = byDate[d];
              const blk = BLOCKED[d] ?? blocked[d];
              return (
                <div key={d} className="flex flex-wrap items-center gap-3 border-b border-border px-4 py-2 text-sm last:border-0">
                  <span className="w-28 font-medium">{fmt(d)}</span>
                  {b ? (
                    <>
                      <span className="flex-1">{b.school_name} · {b.teachers_count} מורים · <span className="text-muted-foreground">{STATUS[b.status]}</span></span>
                      <Assign value={b.instructor} onChange={(v) => act(b.id, "assign", { instructor: v })} />
                      {!b.instructor && <span className="text-xs text-destructive">ללא מדריך</span>}
                    </>
                  ) : <span className="flex-1 text-muted-foreground">{blk ? `חסום – ${blk}` : "פנוי"}</span>}
                </div>
              );
            })}
          </div>
        )}

        {tab === "days" && (
          <div className="overflow-hidden rounded-2xl border border-border bg-card">
            <p className="border-b border-border p-3 text-sm text-muted-foreground">חסימת יום מסתירה אותו מבתי הספר. ימי חג קבועים אינם ניתנים לשינוי.</p>
            {days.map((d) => {
              const fixed = BLOCKED[d];
              const b = byDate[d];
              return (
                <div key={d} className="flex items-center gap-3 border-b border-border px-4 py-2 text-sm last:border-0">
                  <span className="w-28 font-medium">{fmt(d)}</span>
                  <span className="flex-1 text-muted-foreground">{fixed ? `חג – ${fixed}` : blocked[d] ? `חסום – ${blocked[d]}` : b ? `מפגש: ${b.school_name}` : "זמין"}</span>
                  {!fixed && !b && (blocked[d]
                    ? <button onClick={() => run(block({ data: { day: d, block: false } }))} className="rounded-lg border border-border px-3 py-1">שחרור</button>
                    : <button onClick={() => { const r = window.prompt("סיבת החסימה (לא חובה)") ; if (r !== null) run(block({ data: { day: d, block: true, reason: r } })); }} className="rounded-lg border border-border px-3 py-1">חסימה</button>)}
                </div>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}

function Assign({ value, onChange }: { value: string | null; onChange: (v: "טל" | "שני" | null) => void }) {
  return (
    <select value={value ?? ""} onChange={(e) => onChange((e.target.value || null) as "טל" | "שני" | null)} aria-label="שיבוץ מדריך" className="rounded-lg border border-input bg-background px-2 py-1.5 text-sm">
      <option value="">מדריך: לא שובץ</option>
      <option value="טל">טל</option>
      <option value="שני">שני</option>
    </select>
  );
}
