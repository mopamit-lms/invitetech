import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import logo from "@/assets/prismind-logo.png.asset.json";
import { BLOCKED, SERVICE_NAME, dayState, iso } from "@/lib/booking";
import { createBooking, getTakenDates } from "@/lib/bookings.functions";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Prismind – הזמנת ליווי טכנולוגי למורים" },
      { name: "description", content: "יומן הזמנת ליווי טכנולוגי למורים בבתי ספר, נובמבר–דצמבר 2026." },
      { property: "og:title", content: "Prismind – הזמנת ליווי טכנולוגי למורים" },
      { property: "og:description", content: "בחרו בוקר פנוי והזמינו ליווי טכנולוגי למורי בית הספר." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Index,
});

const MONTHS = [{ y: 2026, m: 10, name: "נובמבר 2026" }, { y: 2026, m: 11, name: "דצמבר 2026" }];
const DOW = ["א׳", "ב׳", "ג׳", "ד׳"];
const fmt = (d: string) => new Date(d + "T12:00:00").toLocaleDateString("he-IL", { weekday: "long", day: "numeric", month: "long" });

const EMPTY = { schoolName: "", schoolSymbol: "", city: "", contactName: "", contactRole: "", teachers: "", bellHours: "", notes: "" };

function Index() {
  const qc = useQueryClient();
  const fetchTaken = useServerFn(getTakenDates);
  const submit = useServerFn(createBooking);
  const { data: cal } = useQuery({ queryKey: ["taken"], queryFn: () => fetchTaken() });
  const taken = new Set(cal?.taken ?? []);
  const extraBlocked = cal?.blocked ?? {};
  const ready = !!cal;

  const [selected, setSelected] = useState<string | null>(null);
  const [form, setForm] = useState(EMPTY);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [done, setDone] = useState<string | null>(null);

  const set = (k: keyof typeof EMPTY) => (e: { target: { value: string } }) => setForm((f) => ({ ...f, [k]: e.target.value }));

  async function book(e: React.FormEvent) {
    e.preventDefault();
    if (!selected) return;
    const n = Number(form.teachers);
    if (!Number.isInteger(n) || n < 1) { setErr("יש להזין מספר מורים (לפחות 1)."); return; }
    setBusy(true); setErr(null);
    try {
      const res = await submit({ data: {
        date: selected, schoolName: form.schoolName, schoolSymbol: form.schoolSymbol, city: form.city,
        contactName: form.contactName, contactRole: form.contactRole || undefined,
        teachersCount: n, bellHours: form.bellHours, notes: form.notes || undefined,
      } });
      if (!res.ok) { setErr(res.error); qc.invalidateQueries({ queryKey: ["taken"] }); }
      else { setDone(selected); setSelected(null); setForm(EMPTY); qc.invalidateQueries({ queryKey: ["taken"] }); }
    } catch {
      setErr("הפרטים שהוזנו אינם תקינים. בדקו את השדות ונסו שוב.");
    } finally { setBusy(false); }
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="mx-auto flex max-w-3xl items-center justify-between px-4 py-3">
          <img src={logo.url} alt="Prismind" className="h-8 w-auto" />
          <Link to="/auth" className="text-sm text-muted-foreground underline hover:text-primary">כניסת צוות</Link>
        </div>
      </header>

      <main className="mx-auto max-w-3xl space-y-6 px-4 py-6">
        <section className="rounded-2xl bg-primary p-5 text-primary-foreground">
          <h1 className="text-2xl font-bold">הזמנת {SERVICE_NAME}</h1>
          <p className="mt-1 text-sm opacity-80">בחרו בוקר פנוי (א׳–ד׳, 09:00–13:00).</p>
        </section>

        {done && (
          <div role="status" className="rounded-xl border border-success/40 bg-success/10 p-3 text-sm">
            הבקשה ל{fmt(done)} נשלחה וממתינה לאישור. ניצור קשר לאחר השיבוץ.
          </div>
        )}

        {!ready && <p className="text-sm text-muted-foreground">טוען זמינות…</p>}
        <Legend />

        {MONTHS.map(({ y, m, name }) => (
          <section key={name} className="rounded-2xl border border-border bg-card p-4">
            <h2 className="mb-3 text-lg font-semibold">{name}</h2>
            <div className="grid grid-cols-4 gap-2">
              {DOW.map((d) => <div key={d} className="text-center text-xs font-medium text-muted-foreground">{d}</div>)}
              {monthCells(y, m).map((date, i) => {
                if (!date) return <div key={i} />;
                const st = dayState(taken, date, extraBlocked);
                const day = Number(date.slice(-2));
                const clickable = ready && st === "free";
                const label = !ready ? "" : { outside: "", blocked: BLOCKED[date] ?? extraBlocked[date] ?? "חסום", taken: "תפוס", free: "פנוי" }[st];
                const cls = !ready ? "bg-muted/50 text-muted-foreground" : {
                  outside: "text-muted-foreground/40",
                  blocked: "bg-muted text-muted-foreground",
                  taken: "bg-muted text-muted-foreground line-through",
                  free: "bg-free text-foreground hover:ring-2 hover:ring-primary",
                }[st];
                return (
                  <button
                    key={date}
                    disabled={!clickable}
                    onClick={() => { setSelected(date); setErr(null); setDone(null); }}
                    aria-label={`${fmt(date)} – ${label || "לא זמין"}`}
                    className={`flex h-16 flex-col items-center justify-center rounded-xl text-sm transition disabled:cursor-not-allowed ${cls}`}
                  >
                    <span className="text-base font-semibold">{day}</span>
                    <span className="text-[11px]">{label}</span>
                  </button>
                );
              })}
            </div>
          </section>
        ))}
      </main>

      {selected && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-foreground/40 sm:items-center" onClick={() => setSelected(null)}>
          <form role="dialog" aria-modal onSubmit={book} className="max-h-[92vh] w-full max-w-md space-y-3 overflow-y-auto rounded-t-2xl bg-card p-5 sm:rounded-2xl" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-lg font-bold">{SERVICE_NAME} – {fmt(selected)}</h3>
            <p className="text-sm text-muted-foreground">09:00–13:00 · בבית הספר</p>
            <Field label="שם בית הספר" value={form.schoolName} onChange={set("schoolName")} max={100} />
            <Field label="סמל מוסד" value={form.schoolSymbol} onChange={set("schoolSymbol")} max={12} inputMode="numeric" />
            <Field label="יישוב" value={form.city} onChange={set("city")} max={60} />
            <Field label="כמה מורים יקבלו ליווי?" value={form.teachers} onChange={set("teachers")} max={3} type="number" inputMode="numeric" />
            <Field label="שם איש/ת קשר" value={form.contactName} onChange={set("contactName")} max={80} />
            <Field label="תפקיד (לא חובה)" value={form.contactRole} onChange={set("contactRole")} max={60} optional />
            <label className="block text-sm font-medium">
              שעות הצלצולים של בית הספר
              <textarea required value={form.bellHours} maxLength={200} onChange={set("bellHours")} placeholder="לדוגמה: 8:00–8:45, 8:45–9:30" className="mt-1 w-full rounded-lg border border-input bg-background p-2 text-sm" rows={2} />
            </label>
            <label className="block text-sm font-medium">
              הערות (לא חובה)
              <textarea value={form.notes} maxLength={300} onChange={set("notes")} placeholder="ללא פרטים אישיים של מורים או תלמידים" className="mt-1 w-full rounded-lg border border-input bg-background p-2 text-sm" rows={2} />
            </label>
            {err && <p role="alert" className="rounded-lg bg-destructive/10 p-2 text-sm text-destructive">{err}</p>}
            <div className="flex gap-2">
              <button disabled={busy} type="submit" className="flex-1 rounded-lg bg-primary py-2.5 font-medium text-primary-foreground hover:bg-primary/90 disabled:opacity-60">{busy ? "שולח..." : "שליחת בקשה"}</button>
              <button type="button" onClick={() => setSelected(null)} className="rounded-lg border border-border px-4 py-2.5">ביטול</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

function Field({ label, value, onChange, max, type = "text", inputMode, optional }: {
  label: string; value: string; onChange: (e: { target: { value: string } }) => void; max: number;
  type?: string; inputMode?: "numeric"; optional?: boolean;
}) {
  return (
    <label className="block text-sm font-medium">
      {label}
      <input required={!optional} type={type} inputMode={inputMode} min={type === "number" ? 1 : undefined} value={value} maxLength={max} onChange={onChange}
        className="mt-1 w-full rounded-lg border border-input bg-background p-2 text-sm" />
    </label>
  );
}

function Legend() {
  const items = [["bg-free", "פנוי"], ["bg-muted", "תפוס / חסום"]];
  return (
    <div className="flex flex-wrap gap-4 text-sm">
      {items.map(([c, l]) => <span key={l} className="flex items-center gap-1.5"><span className={`h-4 w-4 rounded ${c}`} />{l}</span>)}
    </div>
  );
}

function monthCells(y: number, m: number): (string | null)[] {
  const cells: (string | null)[] = [];
  const d = new Date(y, m, 1);
  const first = d.getDay();
  if (first <= 3) for (let i = 0; i < first; i++) cells.push(null);
  while (d.getMonth() === m) {
    if (d.getDay() <= 3) cells.push(iso(d));
    d.setDate(d.getDate() + 1);
  }
  return cells;
}
