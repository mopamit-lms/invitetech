export const WINDOW_START = "2026-11-04";
export const WINDOW_END = "2026-12-31";
export const SERVICE_NAME = "ליווי טכנולוגי למורים";

// Ministry of Education holidays / blocked days (Hanukkah 2026: Dec 6–12 approx.)
export const BLOCKED: Record<string, string> = {
  "2026-12-06": "חנוכה",
  "2026-12-07": "חנוכה",
  "2026-12-08": "חנוכה",
  "2026-12-09": "חנוכה",
};

export const iso = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

export type DayState = "outside" | "blocked" | "taken" | "free";

export function dayState(taken: Set<string>, date: string, extra: Record<string, string> = {}): DayState {
  const dow = new Date(date + "T12:00:00").getDay();
  if (date < WINDOW_START || date > WINDOW_END || dow > 3) return "outside";
  if (BLOCKED[date] || extra[date]) return "blocked";
  return taken.has(date) ? "taken" : "free";
}
