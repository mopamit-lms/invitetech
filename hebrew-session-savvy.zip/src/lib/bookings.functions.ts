import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { WINDOW_START, WINDOW_END, BLOCKED } from "./booking";

export const getTakenDates = createServerFn({ method: "GET" }).handler(async () => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const [b, d] = await Promise.all([
    supabaseAdmin.from("bookings").select("session_date").not("status", "in", "(cancelled,rejected)"),
    supabaseAdmin.from("blocked_days").select("day, reason"),
  ]);
  if (b.error || d.error) throw new Error("שגיאה בטעינת היומן");
  return {
    taken: (b.data ?? []).map((r) => r.session_date),
    blocked: Object.fromEntries((d.data ?? []).map((r) => [r.day, r.reason])) as Record<string, string>,
  };
});

const schema = z.object({
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  schoolName: z.string().trim().min(2).max(100),
  schoolSymbol: z.string().trim().min(3).max(12),
  city: z.string().trim().min(2).max(60),
  contactName: z.string().trim().min(2).max(80),
  contactRole: z.string().trim().max(60).optional(),
  teachersCount: z.number().int().min(1).max(500),
  bellHours: z.string().trim().min(4, "יש לציין את שעות הצלצולים של בית הספר.").max(200),
  notes: z.string().trim().max(300).optional(),
});

export const createBooking = createServerFn({ method: "POST" })
  .inputValidator((d) => schema.parse(d))
  .handler(async ({ data }) => {
    const dow = new Date(data.date + "T12:00:00").getDay();
    if (data.date < WINDOW_START || data.date > WINDOW_END || dow > 3 || BLOCKED[data.date]) {
      return { ok: false as const, error: "התאריך אינו זמין להזמנה." };
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: blk } = await supabaseAdmin.from("blocked_days").select("day").eq("day", data.date).maybeSingle();
    if (blk) return { ok: false as const, error: "התאריך אינו זמין להזמנה." };
    const { error } = await supabaseAdmin.from("bookings").insert({
      session_date: data.date,
      school_name: data.schoolName,
      school_symbol: data.schoolSymbol,
      city: data.city,
      contact_name: data.contactName,
      contact_role: data.contactRole || null,
      contact_phone: "",
      contact_email: "",
      teachers_count: data.teachersCount,
      bell_hours: data.bellHours,
      notes: data.notes || null,
    });
    if (error) {
      if (error.message.includes("bookings_one_per_date"))
        return { ok: false as const, error: "הבוקר הזה כבר נתפס. בחרו יום אחר." };
      if (error.message.includes("bookings_one_per_school"))
        return { ok: false as const, error: "בית ספר זה כבר הזמין ליווי טכנולוגי. ניתן להזמין פעם אחת בלבד." };
      return { ok: false as const, error: "אירעה שגיאה בשליחת הבקשה. נסו שוב." };
    }
    return { ok: true as const };
  });
