import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { BLOCKED, WINDOW_END, WINDOW_START } from "./booking";

async function adminClient(ctx: { supabase: any; userId: string }) {
  const { data: ok } = await ctx.supabase.rpc("has_role", { _user_id: ctx.userId, _role: "admin" });
  if (!ok) throw new Error("אין הרשאת ניהול");
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

export const amIAdmin = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
    return !!data;
  });

export const listAdminData = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const db = await adminClient(context);
    const [b, d] = await Promise.all([
      db.from("bookings").select("*").order("session_date"),
      db.from("blocked_days").select("day, reason").order("day"),
    ]);
    if (b.error || d.error) throw new Error("שגיאה בטעינת הנתונים");
    return { bookings: b.data ?? [], blocked: d.data ?? [] };
  });

const dateStr = z.string().regex(/^\d{4}-\d{2}-\d{2}$/);

export const updateBooking = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({
      id: z.string().uuid(),
      action: z.enum(["approve", "reject", "propose", "assign", "cancel"]),
      date: dateStr.optional(),
      instructor: z.enum(["טל", "שני"]).nullable().optional(),
      note: z.string().trim().max(300).optional(),
    }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const db = await adminClient(context);
    const patch: { admin_note?: string | null; status?: string; instructor?: string | null; session_date?: string; original_date?: string | null } = {};
    if (data.note !== undefined) patch.admin_note = data.note || null;
    if (data.action === "approve") patch.status = "approved";
    if (data.action === "reject") patch.status = "rejected";
    if (data.action === "cancel") patch.status = "cancelled";
    if (data.action === "assign") patch.instructor = data.instructor ?? null;
    if (data.action === "propose") {
      if (!data.date) return { ok: false as const, error: "יש לבחור מועד חלופי." };
      const dow = new Date(data.date + "T12:00:00").getDay();
      const { data: blk } = await db.from("blocked_days").select("day").eq("day", data.date).maybeSingle();
      if (data.date < WINDOW_START || data.date > WINDOW_END || dow > 3 || BLOCKED[data.date] || blk)
        return { ok: false as const, error: "המועד החלופי אינו יום פעילות זמין." };
      const { data: cur } = await db.from("bookings").select("session_date, original_date").eq("id", data.id).single();
      patch.status = "proposed";
      patch.session_date = data.date;
      patch.original_date = cur?.original_date ?? cur?.session_date ?? null;
    }
    const { error } = await db.from("bookings").update(patch).eq("id", data.id);
    if (error) {
      if (error.message.includes("one_per_date")) return { ok: false as const, error: "המועד הזה כבר תפוס." };
      return { ok: false as const, error: "העדכון נכשל." };
    }
    return { ok: true as const };
  });

export const setBlockedDay = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({ day: dateStr, block: z.boolean(), reason: z.string().trim().max(60).optional() }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const db = await adminClient(context);
    if (data.block) {
      const { data: b } = await db.from("bookings").select("id").eq("session_date", data.day)
        .not("status", "in", "(cancelled,rejected)").maybeSingle();
      if (b) return { ok: false as const, error: "יש מפגש ביום הזה. יש לדחות או להעביר אותו קודם." };
      const { error } = await db.from("blocked_days").upsert({ day: data.day, reason: data.reason || "חסום" });
      if (error) return { ok: false as const, error: "החסימה נכשלה." };
    } else {
      await db.from("blocked_days").delete().eq("day", data.day);
    }
    return { ok: true as const };
  });
